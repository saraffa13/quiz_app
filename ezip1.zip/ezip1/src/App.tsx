import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import Layout from './components/Layout'
import Home from './pages/Home'
import ProductLayout from './pages/products/ProductLayout'
import ProductList from './pages/products/ProductList'
import axios from 'axios'
import CartContextProvider from './context/CartContext'
import ProductDetails from './pages/products/ProductDetails'
import Cart from './pages/cart/Cart'
import UserContextProvider from './context/UserContext'

async function fetchProducts(url: string) {
  const response = await axios.get(url);
  return response.data;
}

function App() {

  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          index: true,
          element: <Home />
        },
        {
          path: '/products',
          element: <ProductLayout />,
          children: [
            {
              path: '/products/:id',
              element: <ProductDetails />,
              loader: (e) => fetchProducts(`https://fakestoreapi.com/products/${e.params.id}`),
            },
            {
              index: true,
              element: <ProductList />,
              loader: () => fetchProducts("https://fakestoreapi.com/products?limit=10"),
            }
          ]
        },
        {
          path: '/cart',
          element: <Cart />
        },
      ]
    }
  ])

  return (
    <>
      <UserContextProvider>
        <CartContextProvider>
          <RouterProvider router={router} />
        </CartContextProvider>
      </UserContextProvider>
    </>
  )
}

export default App
