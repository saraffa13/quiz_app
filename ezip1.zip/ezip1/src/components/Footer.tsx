const Footer = () => {
  return (
    <div className="bg-black w-screen p-12 text-white flex">
        <h1 className="text-center w-full">@ 2024 All rights reserved.</h1>        
    </div>
  )
}

export default Footer
