const Home = () => {
  return (
    <section className="">
      Home
    </section>
  )
}

export default Home
