import { useLoaderData } from "react-router-dom"

const ProductDetails = () => {
  const data = useLoaderData();
  return (
    <section>

    </section>
  )
}

export default ProductDetails
