import { CartContextConsumer } from "../../context/CartContext";
import ProductCard from "../products/ProductCard";

const Cart = () => {
  const { cart, cartPrice } = CartContextConsumer();

  return (
    <section className="flex flex-col items-center py-10">
      <h1 className="text-center text-4xl font-bold text-gray-800 mb-8">Cart Items</h1>
      <div className="flex flex-col gap-8 w-full max-w-4xl">
        {cart.map((product: any) => (
          <div key={product.id} className="flex justify-between items-center p-5 bg-white shadow-lg rounded-lg border border-gray-300 hover:shadow-xl transition-shadow duration-200">
            <ProductCard product={product} />
            <div className="text-2xl font-bold text-gray-700">
              Price: <span className="text-green-600">${(product.price * product.quantity).toFixed(2)}</span>
            </div>
          </div>
        ))}
        <div className="font-bold text-3xl text-gray-800 border-t border-gray-300 pt-4 mt-6">
          Total Price: <span className="text-green-600">${cartPrice.toFixed(2)}</span>
        </div>
      </div>
    </section>
  );
}

export default Cart;
