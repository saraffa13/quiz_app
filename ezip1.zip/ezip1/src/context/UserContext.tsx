import { createContext, useContext, useState, ReactNode } from "react";
import { CartItem } from "./CartContext";
import { v4 as uuidv4 } from 'uuid';

interface UserType {
    id: string;
    name: string;
    email: string;
    password: string;
    isLoggedIn:boolean;
    cart: CartItem[];
}

interface UserContextType {
    userList: UserType[];
    addUser: (name: string, email: string, password: string) => void;
    verifyUser: (email: string, password: string) => string;
}

const emptyCartList: CartItem[] = [];
const emptyUserList: UserType[] = [];

const defaultUserContext: UserContextType = {   
    userList: emptyUserList,
    addUser: () => {},
    verifyUser: () => ""
};

export const UserContext = createContext<UserContextType>(defaultUserContext);

export const UserContextConsumer = () => {
    const contextConsumer = useContext(UserContext);
    if (!contextConsumer) {
        throw new Error('UserContextConsumer must be used within a UserContextProvider');
    }
    return contextConsumer;
};

interface UserContextProviderProps {
    children: ReactNode;
}

const UserContextProvider: React.FC<UserContextProviderProps> = ({ children }) => {
    const [userList, setUserList] = useState<UserType[]>(emptyUserList);

    const addUser = (name: string, email: string, password: string) => {
        setUserList((prevUserList) => [
            ...prevUserList,
            { id: uuidv4(), name, email, password, cart: emptyCartList, isLoggedIn:true }
        ]);
    };

    const verifyUser = (email: string, password: string) => {
        const checkIfUserExists = userList.find(user => user.email === email);
        if (!checkIfUserExists) return "User doesn't exist.";
        const user = userList.find(user => user.email === email && user.password === password);
        if (user) {
            return "Logged In!";
        } else {
            return "Incorrect Password";
        }
    };

    const loginUser = (email:string) => {
        setUserList((prevUserList:UserType[])=> {
            return prevUserList.map((user:UserType)=>{
                if(user.email === email){
                    return {
                        ...user,
                        isLoggedIn:true,
                    }
                }else{
                    return user;
                }
            })
        } )
    }

    const logoutUser = (email:string) => {
        setUserList((prevUserList:UserType[])=> {
            return prevUserList.map((user:UserType)=>{
                if(user.email === email){
                    return {
                        ...user,
                        isLoggedIn:false,
                    }
                }else{
                    return user;
                }
            })
        } )
    }

    return (
        <UserContext.Provider value={{ userList, addUser, verifyUser }}>
            {children}
        </UserContext.Provider>
    );
};

export default UserContextProvider;
