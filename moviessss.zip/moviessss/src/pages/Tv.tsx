import { Box, Button, Flex } from "@chakra-ui/react";
const Tv = () => {
    return (
        <Box as='nav'>
            Shivam
        </Box>
    )
}

export default Tv
