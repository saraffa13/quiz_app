const ProgressBar = ({ rating }:any) => {
  const percentage = Math.trunc(rating * 10); // Calculate percentage
  const strokeColor = percentage >= 75 ? "#00FF00" : percentage >= 50 ? "#FFFF00" : "#FF0000"; // Dynamic color based on percentage
  
  return (
    <div className="relative flex justify-center items-center">
      <svg className="w-[60px] h-[60px]">
        <circle
          cx="30"
          cy="30"
          r="26"
          stroke="#e6e6e6" // Background circle color
          strokeWidth="6"
          fill="none"
        />
        <circle
          cx="30"
          cy="30"
          r="26"
          stroke={strokeColor}
          strokeWidth="6"
          fill="none"
          strokeDasharray="163.36" // 2 * Math.PI * 26 (circumference of the circle)
          strokeDashoffset={(1 - percentage / 100) * 163.36} // Adjust based on percentage
          strokeLinecap="round"
          transform="rotate(-90 30 30)" // Rotates to start from the top
        />
      </svg>
      <p className="absolute text-center text-xl">{percentage}%</p>
    </div>
  );
};


export const Card = ({ title, date, image, description, rating }: any) => {
  return (
    <div className="flex flex-col">
      <div className="w-[225px] rounded-[10px] bg-cover bg-center relative">
        <img
          src={image}
          className="w-full h-[300px] object-cover rounded-[10px]"
          alt={description}
        />
        <div className="w-16 h-16 bg-white rounded-full absolute bottom-[-35px] right-[145px] flex items-center justify-center">
          <ProgressBar rating={rating}/>
        </div>
      </div>
      <div className="mt-10 w-[225px]">
        <p className="text-[#000] text-xl font-semibold truncate">{title}</p>
        <p className="text-[#757a83] text-sm">{date}</p>
      </div>
    </div>
  );
};

export default Card;
