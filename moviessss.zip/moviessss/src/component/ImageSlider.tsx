import React, { useState } from 'react';
import {
  Box,
  Image,
  Text,
  IconButton,
} from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon } from '@chakra-ui/icons';

const images = [
  { src: '../assets/movie1.jpg', caption: 'Caption for image 1' },
  { src: '../assets/movie2.jpg', caption: 'Caption for image 2' },
  { src: '../assets/movie4.jpg', caption: 'Caption for image 3' },
];

const ImageSlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <Box position="relative" maxW="600px" mx="auto">
      <Image
        src={images[currentIndex].src}
        alt={`Slide ${currentIndex + 1}`}
        borderRadius="md"
        boxSize="full"
        objectFit="cover"
      />
      <Text position="absolute" bottom="4" left="4" color="white" bg="rgba(0, 0, 0, 0.5)" p="2">
        {images[currentIndex].caption}
      </Text>
      <IconButton
        aria-label="Previous Slide"
        icon={<ChevronLeftIcon />}
        position="absolu../assets/movie1.jpgte"
        left="4"
        top="50%"
        transform="translateY(-50%)"
        onClick={handlePrev}
        colorScheme="teal"
      />
      <IconButton
        aria-label="Next Slide"
        icon={<ChevronRightIcon />}
        position="absolute"
        right="4"
        top="50%"
        transform="translateY(-50%)"
        onClick={handleNext}
        colorScheme="teal"
      />
    </Box>
  );
};

export default ImageSlider;
