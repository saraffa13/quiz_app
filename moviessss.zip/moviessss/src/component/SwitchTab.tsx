import React, { useState } from 'react';

const SwitchTab = ({types, fetchTheActiveTabValue}:any) => {
  const [activeTab, setActiveTab] = useState(types[0]);
  
  const handleTabChange = (tab: React.SetStateAction<string>) => {
    setActiveTab(tab);
    fetchTheActiveTabValue(tab);
  };

  return (
    <div className="w-[275px] max-w-sm rounded flex flex-col justify-end text-white">
      <div className=" shadow-lg rounded-full h-10 flex relative items-center">
        <div className="w-full flex justify-center">
          <button
            onClick={() => handleTabChange(types[0])}
            className={`flex-1 text-center py-1 rounded-full transition ${
              activeTab === types[0] ? '' : 'bg-transparent'
            }`}
          >
            {types[0]}
          </button>
        </div>
        <div className="w-full flex justify-center">
          <button
            onClick={() => handleTabChange(types[1])}
            className={`flex-1 text-center py-1 rounded-full transition ${
              activeTab === types[1] ? 'bg-gray-200' : 'bg-transparent'
            }`}
          >
            {types[1]}
          </button>
        </div>
        <span
          style={{
            background: 'linear-gradient(to right, #F58F0F, #DD3960)',
          }}
          className={`elSwitch bg-black shadow text-white flex items-center justify-center w-1/2 rounded-full h-8 transition-all absolute top-[4px] ${
            activeTab === types[0] ? 'left-1' : 'left-[calc(100%-50%)]'
          }`}
        >
          {activeTab}
        </span>
      </div>
    </div>
  );
};

export default SwitchTab;
