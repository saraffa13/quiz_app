import { useEffect, useState } from "react"
import { CarouselSpacing } from "./CarousalSpacing"
import SwitchTab from "./SwitchTab"
import { capitalizeFirstLetter } from "../utils/helper";

const Carousal = ({cardArray, type }:any) => {

  const [types, setTypes] = useState<any>([]);
  const [activeTab, setActiveTab] = useState(()=>{
    return Object.keys(cardArray)[0];
  });

  useEffect(()=>{
    setTypes(Object.keys(cardArray));
  },[])

  const fetchTheActiveTabValue = (val:string) => {
    setActiveTab(val);
  }

  return (
    <div className="">
        <div className=" w-full m-auto p-2 flex justify-between items-center text-white">
            <div className="text-2xl text-[1.4rem] ">{capitalizeFirstLetter(type)}</div>
            {types.length > 0 && <SwitchTab types={types} fetchTheActiveTabValue={fetchTheActiveTabValue} />}
        </div>
       <CarouselSpacing className="m-auto w-full h-auto" cardArray={cardArray[activeTab]} />
    </div>
  )
}

export default Carousal;
