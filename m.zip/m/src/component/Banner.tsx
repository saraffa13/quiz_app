import { Button, Flex, Input } from '@chakra-ui/react'
import Movie1 from '../assets/movie1.jpg'
import Movie2 from '../assets/movie2.jpg'
// import Movie4 from '../assets/movie4.jpg'
import Movie3 from '../assets/movie3.avif'
import Movie7 from '../assets/movie7.avif'
import Movie8 from '../assets/movie8.jpg'
import Movie9 from '../assets/movie9.jpg'
import Movie10 from '../assets/movie10.avif'
import { useState } from 'react'

const images = [Movie1, Movie2, Movie3, Movie7,Movie8,Movie9,Movie10];
const randomImage = images[Math.floor(Math.random() * images.length)];


const Banner = ({fetchTheMovieName}:any) => {

    const [name, setName] = useState<any>('');

    return (
        <Flex>
            <Flex bgRepeat='no-repeat' bgPosition='center' bgSize='cover' opacity='0.6' bgImage={randomImage} position='absolute' w='98.9vw' h='80vh'></Flex>
            <Flex flexDir='column'  w='100vw' h='80vh' justifyContent='center' alignItems='center'>
                <Flex w="50%" flexDir='column' justifyContent='center' alignItems='center' color='white' zIndex='10'>
                    <h1 className='text-8xl text-white font-[800]'>Welcome.</h1>
                    <h2 className='text-[1.4rem]'>Millions of movies, TV shows and people to discover. Explore now.</h2>
                    <Flex w='100%' marginTop='2rem'>
                        <Input value={name} onChange={(e)=>{
                            setName(e.target.value)
                        }} color='black' bg='white' fontSize='1.2rem' padding='1.8rem' placeholder='Search for a movie or TV show' borderLeftRadius='2rem' borderRightRadius='0' borderRight='none'></Input>
                        <Button onClick={()=>{
                            fetchTheMovieName(name);
                            setName('');
                        }} width='20%' padding='1.84rem' borderRightRadius="2rem" borderLeft='none' borderLeftRadius='0' bg="linear-gradient(to right, #F58F0F, #DD3960)" >Search</Button>
                    </Flex>
                </Flex>
            </Flex>
        </Flex>
    )
}

export default Banner
