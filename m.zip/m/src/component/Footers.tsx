import { Box, Container, Flex, Text, Link, HStack, Icon } from '@chakra-ui/react';
import { FaFacebookF, FaInstagram, FaGithub, FaLinkedinIn } from 'react-icons/fa';

const Footer = () => {
  return (
    <Box as="footer" bg='#0a101c' h='auto' color="gray.400" className='py-12'>
      <Container maxW="container.xl" bg='#0a101c' >
        <Flex direction="column" bg='#0a101c'  align="center">
          <HStack spacing={4} bg='#0a101c' mb={4}>
            <Link href="/terms" fontWeight='700' color='white'>Terms Of Use</Link>
            <Link href="/privacy" fontWeight='700' color='white'>Privacy-Policy</Link>
            <Link href="/about" fontWeight='700' color='white'>About</Link>
            <Link href="/blog" fontWeight='700' color='white'>Blog</Link>
            <Link href="/faq" fontWeight='700' color='white'>FAQ</Link>
          </HStack>
          
          <Text textAlign="center" bg='#0a101c'  fontSize="sm" mb={6} maxW="container.md">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
            enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
            in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
          </Text>
          
          <HStack bg='#0a101c' spacing={4}>
            <div className='bg-[#04142C] rounded-[100%] bg-transparent'>
                <SocialIcon className="text-3xl" icon={FaFacebookF} href="https://facebook.com" />
            </div>
            <div className='bg-[#04142C] rounded-[100%] bg-transparent'>
                <SocialIcon className="text-3xl" icon={FaInstagram} href="https://instagram.com" />
            </div>
            <div className='bg-[#04142C] rounded-[100%] bg-transparent'>
                <SocialIcon className="text-3xl" icon={FaGithub} href="https://github.com" />
            </div>
            <div className='bg-[#04142C] rounded-[100%] bg-transparent'>
                <SocialIcon className="text-3xl" icon={FaLinkedinIn} href="https://linkedin.com" />
            </div>
          </HStack>
        </Flex>
      </Container>
    </Box>
  );
};

const SocialIcon = ({ icon, href }:any) => (
  <Link href={href} isExternal>
    <Box
      as="span"
      w={10}
      h={10}

      color="white"
      rounded="full"
      display="flex"
      alignItems="center"
      justifyContent="center"
      transition="all 0.3s"
      _hover={{ bg: 'gray.700' }}
    >
      <Icon as={icon} />
    </Box>
  </Link>
);

export default Footer;