import { Card, CardContent } from "../components/ui/card"

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "../components/ui/carousel"

import { Card as MyCard } from "./Card"

export function CarouselSpacing({types, className, cardArray}:any) {

  return (
    <Carousel className={` ${className} p-0`}>
      <CarouselContent className="-ml-1">
        {cardArray.map((_:any, index:number) => {
          return (
          <CarouselItem key={index} className="pl-1 md:basis-1/2 lg:basis-1/5">
            <div className="p-1">
              <Card>
                <CardContent className="flex aspect-square items-center justify-center p-6">
                  <span className="text-2xl font-semibold">
                    <MyCard title={cardArray[index].title} description={cardArray[index].description} image={cardArray[index].image} rating={cardArray[index].rating} date={cardArray[index].date} />
                  </span>
                </CardContent>
              </Card>
            </div>
          </CarouselItem>
        )}
      )}
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  )
}
