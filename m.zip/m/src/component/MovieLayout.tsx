import { Outlet } from "react-router-dom"

const MovieLayout = () => {
  return (
    <>
        <Outlet />
    </>
  )
}

export default MovieLayout