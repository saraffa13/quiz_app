import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./pages/Home";
import Movies from "./pages/Movies";
import Tv from "./pages/Tv";
import Layout from "./component/Layout";
import axios from 'axios'
import { config, genresKeyValue } from "./utils/helper";
import MovieLayout from "./component/MovieLayout";
import Movie from "./pages/Movie";

const API = [  
"https://api.themoviedb.org/3/trending/movie/day",
"https://api.themoviedb.org/3/trending/movie/week",
"https://api.themoviedb.org/3/movie/popular",
"https://api.themoviedb.org/3/tv/popular",
"https://api.themoviedb.org/3/movie/top_rated",
"https://api.themoviedb.org/3/tv/top_rated",
"https://api.themoviedb.org/3/movie/"
]



export const refractorMoviesData = (movieData1:any) => {
  return movieData1.results.map((ele:any)=>{
    return {
      id:ele.id,
      genre:(()=>{
        return ele.genre_ids.map((id:number)=>{
          return genresKeyValue[id];
        })
      })(),
      popularity:ele.popularity,
      title:ele.title?ele.title:ele.name,
      description:ele.overview,
      rating:ele.vote_average,
      image:'https://image.tmdb.org/t/p/original'+ele.poster_path,
      date:ele.release_date?ele.release_date:ele.first_air_date
    }
  })
}


const fetchMovie =  async (e:any) => {
  const response1 =  (await axios.get(API[6]+e.params.id, config)).data;
  const response2 =  (await axios.get(API[6]+e.params.id+"/credits", config)).data;
  return {
    resp1:response1,
    resp2:response2,
  }
}

const fetchInitialMoviesList = async () => {
  let movies:any = {
    trending:{Day:[],Week:[]},
    popular:{Movies:[],TvShows:[]},
    topRated:{Movies:[],TvShows:[]}
  }
 
  
  const response1 = (await axios.get(API[0], config)).data;
  const response2 = (await axios.get(API[1], config)).data;
  const response3 = (await axios.get(API[2], config)).data;
  const response4 = (await axios.get(API[3], config)).data;
  const response5 = (await axios.get(API[4], config)).data;
  const response6 = (await axios.get(API[5], config)).data;

  console.log(response1);


  movies.trending.Day = refractorMoviesData(response1);
  movies.trending.Week = refractorMoviesData(response2);
  movies.popular.Movies = refractorMoviesData(response3);
  movies.popular.TvShows = refractorMoviesData(response4);
  movies.topRated.Movies = refractorMoviesData(response5);
  movies.topRated.TvShows = refractorMoviesData(response6);
  return movies;
}

export default function App() {
  
  const route = createBrowserRouter([
    {
      path:'/',
      element:<Layout />,
      children:[
        {
          path:'',
          index:true,
          element:<Home />,
          loader:()=>{
            const data = fetchInitialMoviesList()
            return data;
          },
        },
        {
          path:'/explore/movie',
          element:<MovieLayout />,
          children:[
            {
              index:true,
              element:<Movies />
            },
            {
              path:':id',
              element:<Movie />,
              loader: (e)=>fetchMovie(e)
            }
          ]
        },
        {
          path:'/explore/tv',
          element:<Tv />
        },
      ]
    },
  ])

  return (
    <>
      <RouterProvider router={route} />
    </>
  )
}