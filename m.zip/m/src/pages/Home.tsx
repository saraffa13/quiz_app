import Banner from "../component/Banner";
import Carousal from "../component/Carousal";
import { useLoaderData } from "react-router-dom";
import Footer from "../component/Footers";
import { useEffect, useState } from "react";
import Card from "../component/Card";
import { ImCross } from "react-icons/im";
import axios from "axios";
import Loading from "../component/Loading";

const config = {
    headers: {
        accept: 'application/json',
        Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxOTQ5YzJkMjc0ZGMxMTljZjgzOWE2MzJlZTY3Mzg4OSIsIm5iZiI6MTcyNzMxNjc3NC4yODAzOTMsInN1YiI6IjY2ZjRjMWJkNWUzNTRjNTAxMjczZDcyMiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.eJu0B-tJfqWgfcun1seyggRazLsFK3qrnpWpe9usngE'
    }
}

const refractorMoviesData = (movieData1: any) => {
    return movieData1.results.map((ele: any) => {
        return {
            id: ele.id,
            title: ele.title ? ele.title : ele.name,
            description: ele.overview,
            rating: ele.vote_average,
            image: 'https://image.tmdb.org/t/p/original' + ele.poster_path,
            date: ele.release_date ? ele.release_date : ele.first_air_date
        }
    })
}

const Home = () => {
    debugger;
    const trendingMovies: any = useLoaderData();
    const [searchedMovie, setSearchedMovie] = useState<any>([]);

    console.log(searchedMovie);

    const [loading, setLoading] = useState<boolean>(true);

    const fetchTheMovieName = async (val: string) => {
        const response = await axios.get(`https://api.themoviedb.org/3/search/movie?query=${val}&include_adult=false&language=en-US&page=1`, config);
        const movieData = refractorMoviesData(response.data);
        setSearchedMovie(movieData)
    }

    useEffect(() => {
        if (trendingMovies) {
            setTimeout(()=>{
                setLoading(false);
            },2000)
        }
    }, [trendingMovies]);

    return (
        <>
            {loading === true ? <Loading /> : <div className="relative">
                <Banner fetchTheMovieName={fetchTheMovieName} />
                {searchedMovie && searchedMovie.length > 0 &&
                    <div onClick={()=>setSearchedMovie([])} className="bg-opacity-70 bg-black h-[267vh] z-20 w-[100vw] absolute top-0 left-0 ">
                        <div className="flex flex-wrap border rounded-md w-[80vw] h-auto gap-16 py-8 justify-center items-center absolute bg-white z-10 top-20 left-36 ">
                            <button onClick={() => {
                                setSearchedMovie([])
                            }} className="absolute -top-4 -right-4 bg-black h-[2rem] w-[2rem] rounded-[100%] flex  items-center justify-center hover:scale-105">
                                <ImCross className="text-white" />
                            </button>

                            {searchedMovie.map((movie: any) => <Card title={movie.title} description={movie.description} image={movie.image} rating={movie.rating} date={movie.date} />)}
                        </div>
                    </div>

                }
                <div
                    style={{ background: 'linear-gradient(to top, #01a, #000)' }}            >
                    <div className="m-auto w-[80%] pb-9">
                        {Object.keys(trendingMovies).map((ele: any) => <Carousal key={ele} type={ele} cardArray={trendingMovies[ele]} />)}
                    </div>
                    <Footer />
                </div>
            </div>
            }
        </>
    )
}

export default Home
