import { 
    Box, 
    Flex, 
    Image, 
    Text, 
    Heading, 
    Button, 
    Badge, 
    VStack, 
    HStack, 
    Icon, 
    Container 
} from '@chakra-ui/react';
import { FaPlay } from 'react-icons/fa';
import { useLoaderData } from 'react-router-dom';

const convertToHoursAndMinutes = (time: any) => {
    let hours = Math.floor(Number(time) / 60);
    let minutes = Number(time) % 60;
    return `${hours}h ${minutes}m`;
};

const Movie = () => {
    const { resp1: movieData, resp2: castData }: any = useLoaderData();
    console.log(movieData, castData);

    return (
        <Box
            position="relative"
            bgImage={`url(https://image.tmdb.org/t/p/original/${movieData.backdrop_path})`}
            bgSize="cover"
            bgPosition="center"
            bgRepeat="no-repeat"
            minHeight="100vh"
            _before={{
                content: '""',
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                bg: 'rgba(0, 0, 0, 0.7)', // Dark overlay
            }}
        >
            <Container maxW="container.xl" py={20} position="relative" zIndex={1}>
                <Flex
                    direction={{ base: 'column', md: 'row' }}
                    bg="rgba(255, 255, 255, 0.1)"
                    backdropFilter="blur(10px)"
                    borderRadius="lg"
                    overflow="hidden"
                    h={{ base: 'auto', md: '600px' }}
                    gap={4}
                    alignItems='start'
                    p={4}
                >
                    {/* Movie Poster */}
                    <Box h="500px" flexShrink={0}>
                        <Image
                            src={`https://image.tmdb.org/t/p/original/${movieData.poster_path}`}
                            alt={movieData.title}
                            w="100%"
                            h="100%"
                            objectFit="cover"
                            borderRadius="20px"
                        />
                    </Box>

                    {/* Movie Details */}
                    <VStack
                        align="start"
                        pt={2}
                        spacing={5}
                        flex="1"
                        h="100%"
                        overflowY="auto"
                        color="white"
                    >
                        <Heading size="2xl">{movieData.title}</Heading>
                        <Text fontSize="lg" fontStyle="italic" color="gray.400">
                            {movieData.original_title}
                        </Text>

                        {/* Genres */}
                        <HStack spacing={2} wrap="wrap">
                            {movieData.genres.map((ele: any) => (
                                <Badge colorScheme="pink" fontSize="0.8em" p={2} key={ele.id}>
                                    {ele.name}
                                </Badge>
                            ))}
                        </HStack>

                        {/* Rating & Trailer Button */}
                        <HStack spacing={4}>
                            <Box bg="yellow.400" borderRadius="full" px={3} py={1}>
                                <Text fontSize="lg" fontWeight="bold" color="black">
                                    {Math.floor(movieData.vote_average * 10) / 10}
                                </Text>
                            </Box>
                            <Button
                                leftIcon={<Icon as={FaPlay} />}
                                colorScheme="whiteAlpha"
                                variant="solid"
                                size="md"
                            >
                                Watch Trailer
                            </Button>
                        </HStack>

                        {/* Overview */}
                        <Box>
                            <Heading size="md" mb={2}>Overview</Heading>
                            <Text fontSize="md" color="gray.300">
                                {movieData.overview}
                            </Text>
                        </Box>

                        {/* Movie Info */}
                        <Flex wrap="wrap" justify="space-between" w="100%">
                            <Box mb={2} mr={4}>
                                <Text fontSize="xs" fontWeight="bold" color="gray.400">
                                    Status:&nbsp;
                                </Text>
                                <Text fontSize="sm">{movieData.status}</Text>
                            </Box>
                            <Box mb={2} mr={4}>
                                <Text fontSize="xs" fontWeight="bold" color="gray.400">
                                    Release Date:&nbsp;
                                </Text>
                                <Text fontSize="sm">{movieData.release_date}</Text>
                            </Box>
                            <Box mb={2}>
                                <Text fontSize="xs" fontWeight="bold" color="gray.400">
                                    Runtime:&nbsp;
                                </Text>
                                <Text fontSize="sm">{convertToHoursAndMinutes(movieData.runtime)}</Text>
                            </Box>
                        </Flex>

                        {/* Director & Writer */}
                        <Box>
                            <Text fontSize="xs" fontWeight="bold" color="gray.400">
                                Director:
                            </Text>
                            <Text fontSize="sm">{movieData.director || 'Rupert Sanders'}</Text>
                        </Box>
                        <Box>
                            <Text fontSize="xs" fontWeight="bold" color="gray.400">
                                Writer:
                            </Text>
                            <Text fontSize="sm">{movieData.writer || 'Zach Baylin, Will Schneider'}</Text>
                        </Box>

                        {/* Cast Section */}
                        <Box w="100%">
                            <Heading size="lg" mb={4}>Cast</Heading>
                            <Flex wrap="wrap" justify="flex-start" gap={6}>
                                {castData.cast.map((cast: any) => (
                                    <VStack key={cast.id} spacing={2} w="120px">
                                        <Box
                                            w="100px"
                                            h="100px"
                                            borderRadius="full"
                                            overflow="hidden"
                                            boxShadow="md"
                                            bg="gray.600"
                                        >
                                            <Image
                                                src={cast.profile_path 
                                                    ? `https://image.tmdb.org/t/p/w200/${cast.profile_path}` 
                                                    : 'https://via.placeholder.com/100'} // Fallback if no image
                                                alt={cast.name}
                                                w="100%"
                                                h="100%"
                                                objectFit="cover"
                                            />
                                        </Box>
                                        <Text textAlign="center" fontSize="sm" fontWeight="bold" color="white">
                                            {cast.name}
                                        </Text>
                                        <Text fontSize="xs" color="gray.400" textAlign="center">
                                            as {cast.character}
                                        </Text>
                                    </VStack>
                                ))}
                            </Flex>
                        </Box>
                    </VStack>
                </Flex>
            </Container>
        </Box>
    );
};

export default Movie;
