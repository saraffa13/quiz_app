import { Box } from "@chakra-ui/react";
import axios from "axios";
import { useEffect, useState } from "react";
import { refractorMoviesData } from "../App";
import Card from "../component/Card";
import { config } from "../utils/helper";

const fetchAllMovies = async (page:any) => {
    const response = (await axios.get(`https://api.themoviedb.org/3/tv/popular?language=en-US&page=${page}&include_adult=false`, config)).data;
    const data = refractorMoviesData(response);
    return data;
}

const prepareNewMoviesList = (moviesList:any, genre:any) =>{ 
    const newMovieList:any = []
    moviesList.forEach((ele:any)=>{
        if(ele.genre.findIndex((g:any)=>g === genre)!==-1){
            newMovieList.push(ele);
        }
    })
    return newMovieList;

}
const sortNewMoviesList = (moviesList:any, sortValue:any) =>{ 
    const newMovieList:any = [...moviesList]
    newMovieList.sort((a:any,b:any)=>{
        if(sortValue === "popularity+"){
            return b.popularity - a.popularity;
        }else if(sortValue === "popularity-"){
            return a.popularity - b.popularity;
        }else if(sortValue === 'title+'){
            return  a.title.localeCompare(b.title);
        }else if(sortValue === 'title-'){
            return b.title.localeCompare(a.title);
        }else if(sortValue === 'date+'){
            return  a.date.localeCompare(b.date);
        }else{
            return  b.date.localeCompare(a.date);
        }
    })
    return newMovieList;
}



const Movies = () => {

    const [moviesList, setMoviesList] = useState<any>([]);
    const [moviesListToBeRendered, setMoviesListToBeRendered] = useState<any>([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [selectedGenre, setSelectedGenre] = useState<string>("");
    const [selectedSort, setSelectedSort] = useState<string>("title+");

    const [genre, setGenre] = useState<any>([]);


    const loadMovies = async (pageNumber:any) => {
        setLoading(true);
        const newMovies = await fetchAllMovies(pageNumber);

        const newGenre:any = new Set();
        newMovies.forEach((movie: any) => {
            newGenre.add(...movie.genre);
        })

        const finalGenre = [...genre]; 

        newGenre.forEach((genreId:any) => {
            if (finalGenre.findIndex(id => id === genreId) === -1) {
                finalGenre.push(genreId); 
            }
        });        

        setGenre(finalGenre);

        setMoviesList((prevMovies :any)=> [...prevMovies, ...newMovies]);
        setLoading(false);
    };

    useEffect(() => {
        loadMovies(page);
    }, [page]);

    useEffect(()=>{
        if( selectedGenre === "" ) {
            setMoviesListToBeRendered(sortNewMoviesList(moviesList, selectedSort));
        }else{
            setMoviesListToBeRendered(sortNewMoviesList(prepareNewMoviesList(moviesList, selectedGenre ), selectedSort))
        }
    },[selectedGenre, selectedSort,  moviesList]);

    useEffect(() => {
        const handleScroll = () => {
            const {scrollTop, clientHeight, scrollHeight} = document.documentElement;
            if (scrollHeight-scrollTop <= clientHeight && !loading ) {
                setPage(prevPage => prevPage + 1);
            }
        };
        
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, [loading]);

    return (
        <>
         <Box className="bg-transparent bg-opacity-80 pt-24 flex flex-col justify-center items-center gap-10 pd-16">
            <Box className="w-[60%] flex justify-between">
                <h1 className=" text-2xl">Explore Movies</h1>
                <div className="w-fit flex gap-8">
                    <select className="w-[15rem] rounded-md p-2" onChange={(e)=>{
                        setSelectedGenre(e.target.value);
                    }}>
                        <option value="" >Select Genre</option>
                        {genre && genre.length > 0 && genre.map((ele:any) => <option key={ele} value={ele}>{ele}</option>)}
                    </select>

                    <select className="w-[15rem] rounded-md p-2" onChange={(e)=>{
                        console.log(e.target.value);
                        setSelectedSort(e.target.value);
                    }}>
                        {/* <option value="" >Sort By</option> */}
                        <option value="title+" >Title Asc </option>
                        <option value="title-" >Title Dsc </option>
                        <option value="popularity+" >Popularity Asc </option>
                        <option value="popularity-" >Popularity Dsc</option>
                        <option value="date+" >Release Date Asc </option>
                        <option value="date-" >Release Date Dsc </option>
                    </select>
                </div>
            </Box>
            <Box className="w-[60%] flex flex-wrap justify-between items-center gap-10 pd-16 px-0 ">
                {moviesListToBeRendered.map((movie:any) => (
                    <Card title={movie.title} key={movie.id} date={movie.date} description={movie.description}  image={movie.image} rating={movie.rating}/>
                ))}

            </Box>
        </Box>
        {/* } */}
        </>
    );
}

export default Movies;

