import { createContext, ReactNode, useContext, useEffect, useState } from "react"
import { UserContextConsumer } from "./UserContext"

export interface CartItem {
    id: number,
    title: string,
    price: number,
    quantity: number,
};

export interface CartContextType {
    cart: CartItem[]
    cartPrice: number
    addItemsToCart: any
    alterQuantity: any
    deleteItemFromCart: any
    alterPrice: any
};

const defaultCartContext: CartContextType = {
    cart: [],
    cartPrice: 0,
    addItemsToCart: () => { },
    alterQuantity: () => { },
    deleteItemFromCart: () => { },
    alterPrice: () => { },
};


export const CartContext: React.Context<CartContextType> = createContext(defaultCartContext);

export const CartContextConsumer = () => {
    const contextConsumer = useContext(CartContext);
    if (!contextConsumer) {
        throw new Error('CartContextConsumer must be used within a CartContextProvider')
    } else {
        return contextConsumer;
    }
}

interface CartContextProviderProps {
    children:ReactNode
}

const CartContextProvider: React.FC<CartContextProviderProps> = ({ children }) => {

    const [cart, setCart] = useState<CartItem[]>([]);
    const [cartPrice, setCartPrice] = useState<number>(0);

    const { user } = UserContextConsumer();

    // useEffect(()=>{
    //     setCart(user.cart);
    // },[])

    useEffect(()=>{
        console.log(cart, user);
    },[cart])

    const alterPrice = (quantity: number, price: number, type: number) => {
        setCartPrice((cartPrice: number) => cartPrice + type * price * quantity);
    }

    const addItemsToCart: (product: any, quantity: number) => void = (product, quantity) => {
        setCart((prev: CartItem[]) => [...prev, { ...product, quantity }])
        alterPrice(1, product.price, +1);
    }

    const alterQuantity: (product: any, type: number) => void = (product, type) => {
        setCart((prev: CartItem[]) => {
            return prev.map((cartItem: CartItem) => {
                if (cartItem.id === product.id) {
                    return {
                        ...cartItem,
                        quantity: cartItem.quantity + type
                    }
                } else {
                    return cartItem;
                }
            })
        })
        alterPrice(1, product.price, type);
    }

    const deleteItemFromCart: (product: any, quantity: number) => void = (product, quantity) => {
        setCart((prev: CartItem[]) => {
            return prev.filter((cartItem: CartItem) => {
                return cartItem.id !== product.id
            })
        })
        alterPrice(quantity, product.price, -1);
    }

    return (
        <>
            <CartContext.Provider value={{ cart, cartPrice, addItemsToCart, alterQuantity, deleteItemFromCart, alterPrice }}>{children}</CartContext.Provider>
        </>
    )
}

export default CartContextProvider
