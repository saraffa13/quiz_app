import { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { UserContextConsumer } from '../UserContext'

const RequireAuth:React.FC<{children:ReactNode}> = ({children}) => {
    
    const {user} = UserContextConsumer();
   
    if(user.email!=="")return children;
    else return <Navigate to="/login"/>
    
}

export default RequireAuth