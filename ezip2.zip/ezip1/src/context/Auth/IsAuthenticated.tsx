import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { UserContextConsumer } from '../UserContext';

const IsAuthenticated:React.FC<{children:ReactNode}> = ({children}) => {
   const {user} = UserContextConsumer();
   console.log(user);
   return user.isLoggedIn ? <Navigate to="/"/> : children;
}

export default IsAuthenticated