import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { CartItem } from "./CartContext";
import { v4 as uuidv4 } from 'uuid';

export interface UserType {
    id: string;
    name: string;
    email: string;
    password: string;
    isLoggedIn:boolean;
    cart: CartItem[];
}

interface UserContextType {
    user:UserType,
    userList: UserType[];
    addUser: (name: string, email: string, password: string) => void;
    verifyUser: (email: string, password: string) => string;
    loginUser : (email:string)=>void,
    logoutUser : (email:string)=>void
}

const emptyCartList: CartItem[] = [];
const emptyUserList: UserType[] = [];

const initialUser: UserType ={
    id:"",
    name:"",
    email:"",
    password:"",
    isLoggedIn:false,
    cart:emptyCartList
}
const defaultUserContext: UserContextType = {   
    user:initialUser,
    userList: emptyUserList,
    addUser: () => {},
    verifyUser: () => "",
    loginUser : ()=>{},
    logoutUser : () => {},
};

export const UserContext = createContext<UserContextType>(defaultUserContext);

export const UserContextConsumer = () => {
    const contextConsumer = useContext(UserContext);
    if (!contextConsumer) {
        throw new Error('UserContextConsumer must be used within a UserContextProvider');
    }
    return contextConsumer;
};

interface UserContextProviderProps {
    children: ReactNode;
}

const UserContextProvider: React.FC<UserContextProviderProps> = ({ children }) => {
    const [userList, setUserList] = useState<UserType[]>(emptyUserList);
    const [user, setUser] = useState<UserType>(initialUser);

    useEffect(()=>{
        console.log(userList);
        console.log(user);
    }, [userList])

    const addUser = (name: string, email: string, password: string) => {
        setUserList((prevUserList) => [
            ...prevUserList,
            { id: uuidv4(), name, email, password, cart: emptyCartList, isLoggedIn:false }
        ]);
    };

    const verifyUser = (email: string, password: string) => {
        const checkIfUserExists = userList.find(user => user.email === email);
        if (!checkIfUserExists) return "User doesn't exist.";
        const user = userList.find(user => user.email === email && user.password === password);
        if (user) {
            return "Logged In!";
        } else {
            return "Incorrect Password";
        }
    };

    const loginUser = (email:string) => {
        setUserList((prevUserList:UserType[])=> {
            return prevUserList.map((user:UserType)=>{
                if(user.email === email){
                    const updatedUser:UserType =  {
                        ...user,
                        isLoggedIn:true,
                    }
                    setUser(updatedUser);
                    return updatedUser;
                }else{
                    return user;
                }
            })
        } )
    }

    const logoutUser = (email:string) => {
        setUser(initialUser);
        setUserList((prevUserList:UserType[])=> {
            return prevUserList.map((user:UserType)=>{
                if(user.email === email){
                    return {
                        ...user,
                        isLoggedIn:false,
                    }
                }else{
                    return user;
                }
            })
        } )
    }

    return (
        <UserContext.Provider value={{ user, userList, addUser, verifyUser, loginUser, logoutUser }}>
            {children}
        </UserContext.Provider>
    );
};

export default UserContextProvider;
