import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import Layout from './components/Layout'
import Home from './pages/Home'
import ProductLayout from './pages/products/ProductLayout'
import ProductList from './pages/products/ProductList'
import axios from 'axios'
import CartContextProvider from './context/CartContext'
import ProductDetails from './pages/products/ProductDetails'
import Cart from './pages/cart/Cart'
import UserContextProvider from './context/UserContext'
import Login from './pages/Login/Login'
import SignUp from './pages/Login/SignUp'

import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify'
import Profile from './pages/Login/Profile'
import RequireAuth from './context/Auth/RequireAuth'
import Blog from './pages/Blog/Blog'
import IsAuthenticated from './context/Auth/IsAuthenticated'


async function fetchProducts(url: string) {
  const response = await axios.get(url);
  return response.data;
}

function App() {

  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          index: true,
          element: <RequireAuth> <Home /></RequireAuth>
        },
        {
          path: '/login',
          element:<IsAuthenticated> <Login /></IsAuthenticated>
        },
        {
          path: '/signup',
          element:<IsAuthenticated> <SignUp /></IsAuthenticated>
        },
        {
          path: '/profile',
          element: <RequireAuth> <Profile /></RequireAuth>
        },
        {
          path: '/blogs',
          element: <RequireAuth> <Blog /></RequireAuth>
        },
        {
          path: '/products',
          element: <ProductLayout />,
          children: [
            {
              path: '/products/:id',
              element: <RequireAuth>  <ProductDetails /></RequireAuth>,
              loader: (e) => fetchProducts(`https://fakestoreapi.com/products/${e.params.id}`),
            },
            {
              index: true,
              element: <RequireAuth>  <ProductList /></RequireAuth>,
              loader: () => fetchProducts("https://fakestoreapi.com/products?limit=10"),
            }
          ]
        },
        {
          path: '/cart',
          element: <RequireAuth>  <Cart /></RequireAuth>
        },
      ]
    }
  ])

  return (
    <>
      <ToastContainer />
      <UserContextProvider>
        <CartContextProvider>
          <RouterProvider router={router} />
        </CartContextProvider>
      </UserContextProvider>
    </>
  )
}

export default App
