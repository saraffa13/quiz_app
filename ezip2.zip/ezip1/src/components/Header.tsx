import { Link, useLocation } from "react-router-dom"

import Logo from '../../public/logo.webp'
import { useContext } from "react"
import { CartContext } from "../context/CartContext"
import { CgProfile } from "react-icons/cg"
import { UserContextConsumer } from "../context/UserContext"

const Header = () => {

    const { cart } = useContext(CartContext)
    const { user } = UserContextConsumer();
    const {pathname} = useLocation();

    return (
        <header className="header w-screen bg-black text-white">
            <nav className="nav w-full flex items-center justify-between px-32">
                <div>
                    <img src={Logo} alt="" className="h-[6rem]" />
                </div>
                <ul className="flex gap-8">
                    {user.isLoggedIn &&
                        <>
                            <li>
                                <Link to='/'> Home</Link>
                            </li>
                            <li>
                                <Link to='/products'> Products</Link>
                            </li>
                            <li>
                                <Link to='blogs'> Blog</Link>
                            </li>
                            <li>
                                <Link to='cart'> Cart ({cart.length})</Link>
                            </li>
                            <li>
                                <Link to='/contact'> Contact</Link>
                            </li>
                            <li className="flex justify-center items-center text-2xl">
                                <Link to='/profile'> <CgProfile /></Link>
                            </li>
                        </>
                    }
                    {user.isLoggedIn === false && <li className="border border-white bg-blue-950 p-2 rounded-md">
                        <Link to={`${pathname === '/signup'?'/login':'/signup'}`}> {pathname === '/signup'?'Login':'Signup'} </Link>
                    </li>}
                </ul>
            </nav>
        </header>
    )
}

export default Header
