import { Outlet } from "react-router-dom"

const ProductLayout = () => {
  return (
    <>
        <Outlet />
    </>
  )
}

export default ProductLayout
