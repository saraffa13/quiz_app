import { useLoaderData } from "react-router-dom"
import ProductCard from "./ProductCard";

const ProductList = () => {

  const productsData: any = useLoaderData();

  return (
    <section className="flex flex-col">
      <h1 className="text-center text-4xl font-bold">Product List</h1>
      <div className="flex justify-center flex-wrap gap-10">
        {productsData.map((product: any) => <ProductCard key={product.id} product={product} />)}
      </div>
    </section>
  )

}

export default ProductList;
