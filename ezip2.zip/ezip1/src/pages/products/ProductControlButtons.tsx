import { useContext } from "react";
import { IoMdAdd } from "react-icons/io";
import { MdDelete } from "react-icons/md";
import { RiSubtractFill } from "react-icons/ri";
import { CartContext } from "../../context/CartContext";

interface ProductControlButtons {
    product: any;
    quantity: number;
}

const ProductControlButtons: React.FC<ProductControlButtons> = ({ product, quantity }) => {
    const { alterQuantity, deleteItemFromCart } = useContext(CartContext);

    return (
        <div className="flex justify-between items-center bg-gray-200 p-2 mt-2 rounded-lg shadow-md">
            <div className="flex items-center space-x-2">
                <button
                    disabled={quantity === 1}
                    onClick={(e: any) => {
                        e.preventDefault();
                        alterQuantity(product, -1);
                    }}
                    className={`flex justify-center items-center border border-gray-500 text-blue-900 bg-blue-300 rounded-lg w-8 h-8 transition-colors duration-200 
                    ${quantity === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-400'}`}
                >
                    <RiSubtractFill />
                </button>
                <p className="font-bold text-lg text-gray-800">{quantity}</p>
                <button
                    onClick={(e: any) => {
                        e.preventDefault();
                        alterQuantity(product, +1);
                    }}
                    className="border border-gray-500 text-blue-900 bg-blue-300 rounded-lg w-8 h-8 flex justify-center items-center transition-colors duration-200 hover:bg-blue-400"
                >
                    <IoMdAdd />
                </button>
            </div>
            <button
                className="border border-gray-500 w-8 h-8 text-white bg-red-500 flex items-center justify-center rounded-lg shadow transition-colors duration-200 hover:bg-red-600"
                onClick={(e: any) => {
                    e.preventDefault();
                    deleteItemFromCart(product, quantity);
                }}
            >
                <MdDelete />
            </button>
        </div>
    );
}

export default ProductControlButtons;
