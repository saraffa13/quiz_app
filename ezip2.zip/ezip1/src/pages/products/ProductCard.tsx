import { useContext } from "react";
import { CartContext, CartItem } from "../../context/CartContext";
import ProductControlButtons from "./ProductControlButtons";
import { Link } from "react-router-dom";

function trimString(text: string, length: number) {
  return text.trim().split(" ").splice(0, length).join(" ").trim();
}

const ProductCard: React.FC<any> = ({ product }) => {
  const { cart, addItemsToCart } = useContext(CartContext);
  const { category, description, image, id, price, rating, title } = product;
  const quantity = cart?.find((cartItem: CartItem) => cartItem.id === id)?.quantity;

  return (
    <Link to={`/products/${id}`} className="border border-gray-300 rounded-lg shadow-lg transition-transform transform hover:scale-105 bg-white w-[25rem] m-4">
      <div className="overflow-hidden rounded-t-lg">
        <img src={image} alt={title} className="h-64 w-full object-cover transition-transform transform hover:scale-110" />
      </div>
      <div className="p-4">
        <h2 className="font-bold text-lg text-center text-gray-800 hover:text-blue-600 transition-colors">{trimString(title, 4)}</h2>
        <p className="bg-green-200 text-center rounded-lg p-2 my-2">{trimString(description, 10)}</p>
        <p className="bg-red-100 text-center font-bold rounded-lg p-2">Price: ${price.toFixed(2)}</p>
        {!quantity ? (
          <div className="w-full flex justify-center mt-4">
            <button
              onClick={(e: any) => {
                e.preventDefault();
                addItemsToCart(product, +1);
              }}
              className="border border-gray-300 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition-colors m-auto p-2 px-6"
            >
              Add to Cart
            </button>
          </div>
        ) : (
          <ProductControlButtons product={product} quantity={quantity} />
        )}
      </div>
    </Link>
  );
};

export default ProductCard;
