import { useState } from "react"
import { UserContextConsumer } from "../../context/UserContext";
import { useNavigate } from "react-router-dom";
import { notify } from "../../utils/helper";


const Login = () => {

    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');

    const { verifyUser, loginUser } = UserContextConsumer();
    const navigate = useNavigate();


    return (
        <section className="flex justify-center items-center flex-col gap-4">
            <h1 className="text-4xl font-semibold">Login Form</h1>
            <form onSubmit={(e:React.FormEvent<HTMLFormElement>)=>{
                e.preventDefault();
                const result = verifyUser(email, password);
                if(result === "User doesn't exist."){
                    notify(result);
                    navigate('/signup')
                }else if(result === "Incorrect Password"){
                    notify("Incorrect Email or Password");

                }else{
                    notify("Login Successful!")
                    loginUser(email);
                    navigate('/');
                }
                setEmail("");
                setPassword("");
            }} className="flex gap-4 flex-col border border-black p-4 bg-yellow-400 border-none">
                <div className="flex gap-4 items-center justify-center">
                    <label htmlFor="email">Enter your Email - </label>
                    <input value={email} onChange={(e: React.ChangeEvent<HTMLInputElement>)=>{
                        setEmail(e.target.value)
                    }} id="email" className="border border-black p-2 rounded-md" placeholder="Enter your Email." />

                </div>
                <div className="flex gap-4 items-center justify-center">
                    <label htmlFor="password">Enter your Password - </label>
                    <input value={password} onChange={(e: React.ChangeEvent<HTMLInputElement>)=>{
                        setPassword(e.target.value)
                    }} id="password" className="border border-black p-2 rounded-md" placeholder="Enter your Password." />
                </div>
                <button className="border border-black bg-blue-500 text-white p-2 border-none">Login</button>
            </form>
        </section>
    )
}

export default Login