import { UserContextConsumer, UserType } from "../../context/UserContext";
import { Link, useNavigate } from "react-router-dom";  // Import Link and useNavigate

const Profile = () => {
  const { userList, logoutUser, user  } = UserContextConsumer();  

  
  const navigate = useNavigate();  

  return (
    <section className="bg-gray-100 py-10 px-4 min-h-screen flex justify-center items-center">
      <div className="max-w-sm bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="bg-gradient-to-r from-purple-500 to-indigo-500 p-6">
          <h1 className="text-white text-3xl font-bold mb-2">
            {user?.name || "Guest"}
          </h1>
          <p className="text-indigo-200 text-sm">{user?.email || "No email available"}</p>
        </div>
        <div className="p-6">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Profile Details</h2>
          <div className="space-y-4">
            <div className="flex items-center">
              <span className="text-gray-500 font-medium mr-2">Name:</span>
              <span className="text-gray-800">{user?.name || "Not Available"}</span>
            </div>
            <div className="flex items-center">
              <span className="text-gray-500 font-medium mr-2">Email:</span>
              <span className="text-gray-800">{user?.email || "Not Available"}</span>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link
              to="/cart"
              className="bg-indigo-500 text-white font-bold py-2 px-4 rounded hover:bg-indigo-600 transition duration-300"
            >
              Go to Cart
            </Link>
          </div>

          <div className="mt-4 text-center">
            <button
              onClick={(e:React.MouseEvent<HTMLButtonElement, MouseEvent>)=>{
                e.preventDefault();
                logoutUser(user.email);
              }}
              className="bg-red-500 text-white font-bold py-2 px-4 rounded hover:bg-red-600 transition duration-300"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Profile;
