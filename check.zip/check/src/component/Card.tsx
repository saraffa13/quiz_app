import React from "react";

const Card = () => {
  return (
    <div className="flex flex-col ">
      <div className="w-[225px] rounded-[10px] bg-cover bg-center relative ">
        <img
          src="https://image.tmdb.org/t/p/original/cSMdFWmajaX4oUMLx7HEDI84GkP.jpg"
          className="w-full h-auto rounded-[10px]"
          alt="Harry Potter"
        />
        <div className="w-16 h-16 bg-white rounded-full absolute bottom-[-35px] right-[145px] flex items-center justify-center">
          <div className="w-[60px] h-[60px] border-[6px] p-2 rounded-full border-[#008000] flex justify-center items-center">
            <p className=" font-medium">7.5</p>
          </div>
        </div>
      </div>
      <div className="mt-10">
        <p className="text-[#f3f4f5] text-xl">Harry Potter and the</p>
        <p className="text-[#757a83] text-sm">24 August, 2023</p>
      </div>
    </div>
  );
};

export default Card;
