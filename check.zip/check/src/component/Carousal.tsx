import { CarouselSpacing } from "./CarousalSpacing"
import SwitchTab from "./SwitchTab"

const Carousal = ({cardArray, type }:any) => {
  return (
    <div className="">
        <div className=" w-full m-auto p-2 flex justify-between items-center text-white">
            <div className="text-2xl text-[1.4rem] ">{type}</div>
            <SwitchTab />

        </div>
       <CarouselSpacing className="m-auto w-full h-auto" cardArray={cardArray} />
      
    </div>
  )
}

export default Carousal
