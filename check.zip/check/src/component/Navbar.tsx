import { Box, Button, Flex, Image } from '@chakra-ui/react'
import React from 'react'
import { AiOutlineSearch } from 'react-icons/ai'
import { Link } from 'react-router-dom'

import Logo from '../assets/logo.svg'

const Navbar = () => {
    return (
        <Box as='nav' display={'flex'} bg='rgba(70, 81, 92, 0.9)' color='white' justifyContent='space-between' paddingY='0.7rem' position='absolute'  top='0' w='100%' zIndex={1}>
            <Flex justifyContent='center' alignItems='center' w='50%'>
                <Image src={Logo} alt="logo"></Image>
            </Flex>
            <Flex justifyContent='center' w='50%' gap='1rem' alignItems='center'>
                <Link to="explore/movie" >Movies</Link>
                <Link to="explore/tv">TV Shows</Link>
                <Button>
                    <AiOutlineSearch />
                </Button>
            </Flex>
        </Box>
    )
}

export default Navbar
