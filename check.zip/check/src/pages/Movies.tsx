import { Box, Button, Flex } from "@chakra-ui/react";
const Movies = () => {
    return (
        <Box as='nav'>
            Shivam
        </Box>
    )
}

export default Movies
