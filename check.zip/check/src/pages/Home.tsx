import Banner from "../component/Banner";
import {
    Carousel,
    CarouselContent,
    CarouselItem,
    CarouselNext,
    CarouselPrevious,
} from "../components/ui/carousel"

import Movie1 from '../assets/movie1.jpg'
import Movie2 from '../assets/movie2.jpg'
import Movie4 from '../assets/movie4.jpg'
import { Image } from "@chakra-ui/react";
import { CarouselSpacing } from "../component/CarousalSpacing";
import { useEffect, useState } from "react";
import { Box } from "lucide-react";
import Card from "../component/Card";
import Carousal from "../component/Carousal";

const array = [
    {
        id: 1,
        image: Movie1,
        title: "Sanam Teri Kasam",
    },
    {
        id: 2,
        image: Movie2,
        title: "Tera Suroor",
    },
    {
        id: 1,
        image: Movie4,
        title: "Gabbar Is Back",
    },
    {
        id: 2,
        image: Movie2,
        title: "Tera Suroor",
    },
    {
        id: 1,
        image: Movie4,
        title: "Gabbar Is Back",
    },
]

const Home = () => {

    const [cardArray, setCardArray] = useState<any>([]);


    useEffect(() => {
        setCardArray(array.map((e)=> <Card />))
    }, [])


    return (
        <div className="">
            <Banner />
            <div
                style={{
                    background: 'linear-gradient(to top, #00f, #000)', // Light blue to black
                }}
                className="">
                
                <div className="m-auto w-[68%]">
                    <Carousal type="Trending" cardArray={cardArray} />
                    <Carousal type="What's Popular" cardArray={cardArray} />
                    <Carousal type="Top Rated" cardArray={cardArray} />
                </div>
            </div>
        </div>
    )
}

export default Home
