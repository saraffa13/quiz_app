import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./pages/Home";
import Movies from "./pages/Movies";
import Tv from "./pages/Tv";
import Layout from "./component/Layout";

export default function App() {

  const route = createBrowserRouter([
    {
      path:'/',
      element:<Layout />,
      children:[
        {
          path:'',
          index:true,
          element:<Home />
        },
        {
          path:'/explore/movie',
          element:<Movies />
        },
        {
          path:'/explore/tv',
          element:<Tv />
        },
      ]

    },
  ])

  return (
    <>
      <RouterProvider router={route} />
    </>
  )
}